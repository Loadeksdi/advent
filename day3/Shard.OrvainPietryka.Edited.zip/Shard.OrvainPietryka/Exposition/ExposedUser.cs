﻿using Shard.OrvainPietryka.Domain;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Exposition
{
    public class ExposedUser
    {
        public String Id { get; }
        public String Pseudo { get; }
        public DateTime DateOfCreation { get; }
        public IReadOnlyDictionary<String, int> ResourcesQuantity { get; }
        public ExposedUser(User user)
        {
            Id = user.Id;
            Pseudo = user.Pseudo;
            DateOfCreation = user.DateOfCreation;
            ResourcesQuantity = user.ResourcesQuantity?.ToDictionary(kv => kv.Key.ToString().ToLower(), kv => kv.Value);
        }
    }
}
