﻿using System.Collections.Generic;

namespace Shard.OrvainPietryka
{
    public class ExposedStarSystem
    {
        public string Name { get; }
        public List<ExposedPlanet> Planets { get; }
        public ExposedStarSystem(StarSystem starSystem)
        {
            Name = starSystem.Name;
            List<ExposedPlanet> exposedPlanets = new List<ExposedPlanet>();
            starSystem.Planets.ForEach(planet => exposedPlanets.Add(new ExposedPlanet(planet)));
            Planets = exposedPlanets;
        }
    }
}