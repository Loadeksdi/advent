﻿using Shard.OrvainPietryka.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Exposition
{
    public class ExposedBuilding
    {
        public String Id { get; }
        public String Type { get; }
        public String System { get; }
        public String Planet { get; }
        public String BuilderId { get; }
        public string ResourceCategory { get; }
        public bool IsBuilt { get; }
        public DateTime? EstimatedBuildTime { get; }
        public ExposedBuilding(Building building)
        {
            Id = building.Id;
            Type = building.GetType().Name.ToLower();
            System = building.Location.StarSystem.Name;
            Planet = building.Location.Planet?.Name;
            BuilderId = building.BuilderId;
            IsBuilt = building.IsBuilt;
            if (!IsBuilt)
            {
                EstimatedBuildTime = building.EstimatedBuildTime;
            }
        }

        [JsonConstructor]
        public ExposedBuilding(string id, string type, string system, string planet, string resourceCategory, string builderId)
        {
            Id = id;
            Type = type;
            System = system;
            Planet = planet;
            ResourceCategory = resourceCategory;
            BuilderId = builderId;
        }

        public ExposedBuilding(Mine mine):this((Building) mine)
        {
            ResourceCategory = mine.ResourceCategory;
        }
    }
}
