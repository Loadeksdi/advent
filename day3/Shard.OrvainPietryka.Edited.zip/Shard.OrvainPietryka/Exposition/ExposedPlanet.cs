﻿using Shard.OrvainPietryka.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka
{
    public class ExposedPlanet
    {
        public String Name { get; }
        public int Size { get; }

        public ExposedPlanet(Planet planet)
        {
            Name = planet.Name;
            Size = planet.Size;
        }
    }
}
