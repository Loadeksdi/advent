﻿using Shard.OrvainPietryka.Domain;
using Shard.OrvainPietryka.Domain.Units;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Exposition
{
    public class ExposedUnit
    {
        public String Id { get; }
        public String Type { get; }
        public String Planet { get; }
        public String System { get; }
        public String DestinationPlanet { get; }
        public String DestinationSystem { get; }
        public DateTime EstimatedTimeOfArrival { get; }
        public int? Health { get; }
        public Dictionary<string, int> ResourcesQuantity { get; }
        public string DestinationShard { get; }

        public ExposedUnit(Unit unit)
        {
            Id = unit.Id;
            Type = unit.GetType().Name.ToLower();
            Planet = unit.CurrentLocation.Planet?.Name;
            System = unit.CurrentLocation.StarSystem.Name;
            DestinationPlanet = unit.DestinationLocation?.Planet?.Name;
            DestinationSystem = unit.DestinationLocation?.StarSystem.Name;
            EstimatedTimeOfArrival = unit.EstimatedTimeOfArrival;
            Health = unit.Health;
            if (unit is Cargo cargo)
            {
                ResourcesQuantity = new();
                cargo.ResourcesQuantity.ToList().ForEach(resource =>
                {
                    ResourcesQuantity.Add(resource.Key.ToString().ToLower(), resource.Value);
                });
            }
        }

        [JsonConstructor]
        public ExposedUnit(string id, string type, string planet, string system, string destinationPlanet, string destinationSystem, int? health, Dictionary<string, int> resourcesQuantity, string destinationShard)
        {
            Id = id;
            Type = type;
            Planet = planet;
            System = system;
            DestinationPlanet = destinationPlanet;
            DestinationSystem = destinationSystem;
            Health = health;
            ResourcesQuantity = resourcesQuantity;
            DestinationShard = destinationShard;
        }

    }
}
