﻿using Shard.OrvainPietryka.Domain;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Exposition
{
    public class ExposedLocation
    {
        public String Planet { get; }
        public String System { get; }
        public IReadOnlyDictionary<String,int> ResourcesQuantity { get; }

        public ExposedLocation(Unit unit)
        {
            System = unit.CurrentLocation.StarSystem.Name;
            if (unit.CurrentLocation.Planet != null)
            {
                Planet = unit.CurrentLocation.Planet.Name;
                var type = unit.GetType().Name.ToLower();
                if (type == "scout")
                {
                    var dict = unit.CurrentLocation.Planet.ResourceQuantity.ToDictionary(kv => kv.Key.ToString().ToLower(), kv => kv.Value);
                    ResourcesQuantity = dict;
                }                
            }            
        }

    }
}
