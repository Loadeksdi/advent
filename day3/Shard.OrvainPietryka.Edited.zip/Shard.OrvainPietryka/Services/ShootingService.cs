﻿using Microsoft.Extensions.Hosting;
using Shard.OrvainPietryka.Domain;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Services
{
    public class ShootingService : IHostedService
    {
        private readonly IClock _clock;
        private readonly UserService _userService;
        public ITimer timer;
        public ShootingService(IClock clock, UserService userService)
        {
            _clock = clock;
            _userService = userService;
        }
        public virtual Task StartAsync(CancellationToken cancellationToken)
        {
            timer = _clock.CreateTimer(_ => StartBattle(), null, new TimeSpan(0, 0, 0), new TimeSpan(0, 0, 1));
            return Task.CompletedTask;
        }

        public virtual Task StopAsync(CancellationToken cancellationToken)
        {
            timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void StartBattle()
        {
            _userService.Users.ForEach(user =>
                user.Units.Where(unit => unit.GetType().IsSubclassOf(typeof(CombatUnit))).ToList().ForEach(unit =>
                {
                    var target = ((CombatUnit)unit).FindTarget(_userService, user);
                    ((CombatUnit)unit).Shoot(target.Item1, target.Item2, _clock);
                }));
            _userService.Users.ForEach(user =>
                user.Units.Where(unit => unit.GetType().IsSubclassOf(typeof(CombatUnit))).ToList().ForEach(unit =>
                {
                    if (((CombatUnit) unit).Health <= 0)
                    {
                        user.Units.Remove(unit);
                    }
                }));
        }
    }
}
