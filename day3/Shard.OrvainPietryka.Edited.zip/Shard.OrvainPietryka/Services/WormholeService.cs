﻿using Microsoft.Extensions.Configuration;
using Shard.OrvainPietryka.Domain;
using Shard.OrvainPietryka.Exposition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Services
{
    public class WormholeService
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public WormholeService(IConfiguration conf, IHttpClientFactory httpClientFactory, SectorService sectorService)
        {
            _httpClientFactory = httpClientFactory;
            foreach (var wormhole in conf.GetSection("Wormholes").GetChildren())
            {
                var currentSystem = sectorService.Systems.Find(system => system.Name == wormhole.GetValue<String>("system"));
                if (currentSystem == null)
                {
                    currentSystem = new StarSystem(wormhole.GetValue<String>("system"), null);
                    sectorService.Systems.Add(currentSystem);
                }
                currentSystem.Wormholes.Add(new Wormhole(wormhole.Key, wormhole.GetValue<Uri>("baseUri"), currentSystem, wormhole.GetValue<String>("user"), wormhole.GetValue<String>("sharedPassword")));
            }

        }

        public async Task<string> JumpInRemoteShard(Wormhole wormhole, ExposedUser user, ExposedUnit unit)
        {
            var client = _httpClientFactory.CreateClient();
            client.BaseAddress = wormhole.ServerObject.BaseUri;
            var auth = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes($"shard-{wormhole.Name}:{wormhole.ServerObject.SharedPassword}")));
            client.DefaultRequestHeaders.Authorization = auth;
            var response = await client.PutAsJsonAsync($"users/{user.Id}", user);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            response = await client.PutAsJsonAsync($"users/{user.Id}/units/{unit.Id}", unit);
            client.Dispose();
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            return ($"{wormhole.ServerObject.BaseUri}users/{user.Id}/units/{unit.Id}");
        }

    }
}
