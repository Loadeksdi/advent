﻿using Shard.OrvainPietryka.Domain;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka
{
    public class SectorService
    {
        public List<StarSystem> Systems { get; } = new();
        public SectorService(MapGenerator mapGenerator)
        {
            var sectorSpecification = mapGenerator.Generate();
            foreach(var systemSpecification in sectorSpecification.Systems)
            {
                var systemPlanets = new List<Planet>();
                foreach(var planet in systemSpecification.Planets)
                {
                    var newPlanet = new Planet(planet.Name, planet.Size, planet.ResourceQuantity);
                    systemPlanets.Add(newPlanet);
                }
                var starSystem = new StarSystem(systemSpecification.Name, systemPlanets);
                Systems.Add(starSystem);
            }
        }

        public Location generateRandomLocation()
        {
            Random rnd = new Random();
            var randomSystem = Systems[rnd.Next(0, Systems.Count)];
            return new Location(null,randomSystem);
        }
    }

}
