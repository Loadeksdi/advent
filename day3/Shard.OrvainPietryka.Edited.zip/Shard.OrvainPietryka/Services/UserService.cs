﻿using Shard.OrvainPietryka.Domain;
using Shard.OrvainPietryka.Domain.Units;
using Shard.OrvainPietryka.Exposition;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Services
{
    public class UserService
    {
        public List<User> Users { get; } = new();
        public UserService()
        {

        }

        public Unit CreateAndAddUnit(ExposedUnit unit, User user, Location location)
        {
            Unit existingUnit = null;
            switch (unit.Type)
            {
                case "scout":
                    {
                        existingUnit = new Scout(unit.Id, location)
                        {
                            DestinationLocation = location
                        };
                        break;
                    }
                case "builder":
                    {
                        existingUnit = new Builder(unit.Id, location)
                        {
                            DestinationLocation = location
                        };
                        break;
                    }
                case "fighter":
                    {
                        existingUnit = new Fighter(unit.Id, location)
                        {
                            DestinationLocation = location
                        };
                        break;
                    }
                case "bomber":
                    {
                        existingUnit = new Bomber(unit.Id, location)
                        {
                            DestinationLocation = location
                        };
                        break;
                    }
                case "cruiser":
                    {
                        existingUnit = new Cruiser(unit.Id, location)
                        {
                            DestinationLocation = location
                        };
                        break;
                    }
                case "cargo":
                    {
                        var cargo = new Cargo(unit.Id, location)
                        {
                            DestinationLocation = location,
                            ResourcesQuantity = unit.ResourcesQuantity?.ToDictionary(kvp => (ResourceKind)Enum.Parse(typeof(ResourceKind), kvp.Key, true), kvp => kvp.Value)
                        };
                        existingUnit = cargo;
                        break;
                    }
            }
            if (unit.Health != null)
            {
                existingUnit.Health = unit.Health ?? 0;
            }
            user.Units.Add(existingUnit);
            return existingUnit;
        }
    }
}
