﻿using Shard.OrvainPietryka.Domain;
using Shard.Shared.Core;
using System.Collections.Generic;

namespace Shard.OrvainPietryka
{
    public class Planet
    {
        public string Name { get; }
        public int Size { get; }
        public Dictionary<ResourceKind, int> ResourceQuantity { get; } = new();

        public Planet(string name, int size, IReadOnlyDictionary<ResourceKind, int> resourceQuantity)
        {
            Name = name;
            Size = size;
            foreach (KeyValuePair<ResourceKind, int> kvp in resourceQuantity)
            {
                ResourceQuantity.Add(kvp.Key, kvp.Value);
            }
        }


    }
}