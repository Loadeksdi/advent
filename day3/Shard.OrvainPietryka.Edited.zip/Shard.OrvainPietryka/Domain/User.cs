﻿using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public class User
    {
        public String Id { get; }
        public String Pseudo { get; }
        public DateTime DateOfCreation { get; }
        public List<Unit> Units { get; } = new();
        public List<Building> Buildings { get; } = new();
        public Dictionary<ResourceKind, int> ResourcesQuantity { get; set; }

        public User(string id, string pseudo, DateTime dateOfCreation)
        {
            Id = id;
            Pseudo = pseudo;
            DateOfCreation = dateOfCreation;
            ResourcesQuantity = new Dictionary<ResourceKind, int>() { { ResourceKind.Aluminium, 0 }, { ResourceKind.Carbon, 20 },{ ResourceKind.Gold, 0 }, { ResourceKind.Iron, 10 }, { ResourceKind.Oxygen, 50 }, { ResourceKind.Titanium, 0 }, { ResourceKind.Water, 50 } };
        }


        public void CreateInitialUnits(SectorService sectorService)
        {
            var scout = new Scout(Guid.NewGuid().ToString(), sectorService);
            Units.Add(scout);
            Units.Add(new Builder(Guid.NewGuid().ToString(), scout.CurrentLocation));
        }
    }
}
