﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain.Units
{
    public class Gun : Weapon
    {
        public Gun(int damage) : base(damage)
        {

        }

        public override bool ShouldFire(DateTime dateTime)
        {
            return (dateTime.Second % 6 == 0);
        }
    }
}
