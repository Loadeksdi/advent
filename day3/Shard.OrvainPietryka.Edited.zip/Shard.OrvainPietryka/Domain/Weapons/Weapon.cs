﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public abstract class Weapon
    {
        public int Damage { get; set; }
        public int ReloadTime { get; set; }

        public Weapon(int damage)
        {
            Damage = damage;
        }

        public abstract bool ShouldFire(DateTime dateTime);
    }
}
