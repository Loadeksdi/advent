﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain.Units
{
    public class Bomb : Weapon
    {
        public Bomb(int damage):base(damage)
        {

        }

        public override bool ShouldFire(DateTime dateTime)
        {
            return (dateTime.Second == 0);
        }
    }
}
