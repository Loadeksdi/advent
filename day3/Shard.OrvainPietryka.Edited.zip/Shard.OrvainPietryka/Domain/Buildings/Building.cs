﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public class Building
    {
        public String Id { get; }
        public String BuilderId { get; }
        public Location Location { get; }
        public Boolean IsBuilt { get; set; }
        public DateTime EstimatedBuildTime { get; set; }

        public Building(Builder builder)
        {
            Id = Guid.NewGuid().ToString();
            BuilderId = builder.Id;
            Location = builder.CurrentLocation;
            IsBuilt = false;
        }        
    }
}
