﻿using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public class Mine : Building
    {
        public string ResourceCategory { get; }
        public Mine(Builder builder, string resourceCategory) : base(builder)
        {
            ResourceCategory = resourceCategory;
        }
        public void StartMiningGaseousResource(User user)
        {
            if (Location.Planet.ResourceQuantity[ResourceKind.Oxygen] > 0)
            {
                UpdateResources(ResourceKind.Oxygen, user);
            }
        }
        public void StartMiningLiquidResource(User user)
        {
            if (Location.Planet.ResourceQuantity[ResourceKind.Water] > 0)
            {
                UpdateResources(ResourceKind.Water, user);
            }
        }

        public void StartMiningSolidResource(User user)
        {
            var resourcesOrderedByQuantity = Location.Planet.ResourceQuantity.Where(kvp => kvp.Key != ResourceKind.Oxygen && kvp.Key != ResourceKind.Water).OrderByDescending(kvp => kvp.Value);
            if (resourcesOrderedByQuantity.Count() > 1)
            {
                if (resourcesOrderedByQuantity.First().Value == resourcesOrderedByQuantity.ElementAt(1).Value)
                {
                    var resourcesOrderedByQuantityAndRarity = resourcesOrderedByQuantity.ThenBy(kvp =>
                        kvp.Key == ResourceKind.Titanium ? 1 :
                        kvp.Key == ResourceKind.Gold ? 2 :
                        kvp.Key == ResourceKind.Aluminium ? 3 :
                        kvp.Key == ResourceKind.Iron ? 4 :
                        kvp.Key == ResourceKind.Carbon ? 5 :
                        6
                    );
                    UpdateResourcesIfPlanetHasSome(resourcesOrderedByQuantityAndRarity, user);
                }
                else
                {
                    UpdateResourcesIfPlanetHasSome(resourcesOrderedByQuantity, user);
                }
            }
            else
            {
                UpdateResourcesIfPlanetHasSome(resourcesOrderedByQuantity, user);
            }
        }

        private void UpdateResourcesIfPlanetHasSome(IOrderedEnumerable<KeyValuePair<ResourceKind, int>> list, User user)
        {
            var firstResourceKind = list.First().Key;
            if (Location.Planet.ResourceQuantity[firstResourceKind] > 0)
            {
                UpdateResources(firstResourceKind, user);
            }
        }
        private void UpdateResources(ResourceKind resourceKind, User user)
        {
            user.ResourcesQuantity[resourceKind]++;
            Location.Planet.ResourceQuantity[resourceKind]--;
        }

    }
}
