﻿using Shard.OrvainPietryka.Domain.Units;
using Shard.OrvainPietryka.Exposition;
using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain.Buildings
{
    public class Starport : Building
    {
        public Starport(Builder builder):base(builder)
        {

        }

        public Unit CreateUnit(ExposedUnit exposedUnit, User user, UserService userService, IClock clock)
        {
            switch (exposedUnit.Type)
            {
                case "scout":
                    {
                        if (user.ResourcesQuantity[ResourceKind.Carbon] >= 5 && user.ResourcesQuantity[ResourceKind.Iron] >= 5)
                        {
                            var scout = new Scout(Guid.NewGuid().ToString(), this.Location);
                            user.Units.Add(scout);
                            user.ResourcesQuantity[ResourceKind.Carbon] -= 5;
                            user.ResourcesQuantity[ResourceKind.Iron] -= 5;
                            return scout;
                        }
                        return null;                        
                    }
                case "builder":
                    {
                        if (user.ResourcesQuantity[ResourceKind.Carbon] >= 5 && user.ResourcesQuantity[ResourceKind.Iron] >= 10)
                        {
                            var builder = new Builder(Guid.NewGuid().ToString(), this.Location);
                            user.Units.Add(builder);
                            user.ResourcesQuantity[ResourceKind.Carbon] -= 5;
                            user.ResourcesQuantity[ResourceKind.Iron] -= 10;
                            return builder;
                        }
                        return null;
                    }
                case "fighter":
                    {
                        if (user.ResourcesQuantity[ResourceKind.Iron] >= 20 && user.ResourcesQuantity[ResourceKind.Aluminium] >= 10)
                        {
                            var fighter = new Fighter(Guid.NewGuid().ToString(), this.Location);
                            user.Units.Add(fighter);
                            user.ResourcesQuantity[ResourceKind.Iron] -= 20;
                            user.ResourcesQuantity[ResourceKind.Aluminium] -= 10;
                            return fighter;
                        }
                        return null;
                    }
                case "bomber":
                    {
                        if (user.ResourcesQuantity[ResourceKind.Iron] >= 30 && user.ResourcesQuantity[ResourceKind.Titanium] >= 10)
                        {
                            var bomber = new Bomber(Guid.NewGuid().ToString(), this.Location);
                            user.Units.Add(bomber);
                            user.ResourcesQuantity[ResourceKind.Iron] -= 20;
                            user.ResourcesQuantity[ResourceKind.Titanium] -= 10;
                            return bomber;
                        }
                        return null;
                    }
                case "cruiser":
                    {
                        if (user.ResourcesQuantity[ResourceKind.Iron] >= 60 && user.ResourcesQuantity[ResourceKind.Gold] >= 20)
                        {
                            var cruiser = new Cruiser(Guid.NewGuid().ToString(), this.Location);
                            user.Units.Add(cruiser);
                            user.ResourcesQuantity[ResourceKind.Iron] -= 60;
                            user.ResourcesQuantity[ResourceKind.Gold] -= 20;
                            return cruiser;
                        }
                        return null;
                    }
                case "cargo":
                    {
                        if (user.ResourcesQuantity[ResourceKind.Carbon] >= 10 && user.ResourcesQuantity[ResourceKind.Iron] >= 10 && user.ResourcesQuantity[ResourceKind.Gold] >= 5)
                        {
                            var cargo = new Cargo(Guid.NewGuid().ToString(), this.Location);
                            user.Units.Add(cargo);
                            user.ResourcesQuantity[ResourceKind.Carbon] -= 10;
                            user.ResourcesQuantity[ResourceKind.Iron] -= 10;
                            user.ResourcesQuantity[ResourceKind.Gold] -= 5;
                            return cargo;
                        }
                        return null;
                    }
                default:
                    return null;
            }
        }
    }
}
