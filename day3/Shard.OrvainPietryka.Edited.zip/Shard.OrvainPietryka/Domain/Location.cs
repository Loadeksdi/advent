﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public class Location
    {
        public Planet Planet { get; set; }
        public StarSystem StarSystem { get; set; }

        public Location(Planet planet, StarSystem starSystem)
        {
            Planet = planet;
            StarSystem = starSystem;
        }
    }
}
