﻿using Shard.OrvainPietryka.Domain.Buildings;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public class Builder : Unit
    {
        public Task BuildTask { get; set; }
        private CancellationTokenSource TokenSource;
        public Building Building { get; set; }
        
        public Builder(string id, Location location): base(id, location)
        {

        }

        public Builder(string id, SectorService sectorService) : base(id, sectorService)
        {

        }

        public void BuildBuilding(Building buildingReference, User user, IClock fakeClock)
        {
            TokenSource = new();
            buildingReference.EstimatedBuildTime = fakeClock.Now.AddMinutes(5);
            BuildTask = BuildBuildingAsync(buildingReference, fakeClock, user, TokenSource.Token);
            Building = buildingReference;
        }

        private async Task BuildBuildingAsync(Building buildingReference, IClock fakeClock, User user, CancellationToken token)
        {
            await fakeClock.Delay(1000 * 60 * 5, token);
            token.ThrowIfCancellationRequested();
            buildingReference.IsBuilt = true;
            BuildTask = null;
            Building = null;
            if (buildingReference.GetType().Name.ToLower() == "mine")
            {
                var mineReference = (Mine)buildingReference;
                fakeClock.CreateTimer(_ =>
                {
                    switch (mineReference.ResourceCategory)
                    {
                        case "liquid":
                            mineReference.StartMiningLiquidResource(user);
                            break;
                        case "gaseous":
                            mineReference.StartMiningGaseousResource(user);
                            break;
                        case "solid":
                            mineReference.StartMiningSolidResource(user);
                            break;
                    }
                }, null, new TimeSpan(0, 1, 0), new TimeSpan(0, 1, 0));
            }
            TokenSource.Dispose();
            TokenSource = null;
        }

        public override void Move(Location destinationLocation, IClock fakeClock)
        {
            if (BuildTask != null)
            {
                TokenSource.Cancel();
                BuildTask = null;
            }
            base.Move(destinationLocation, fakeClock);
        }

    }
}
