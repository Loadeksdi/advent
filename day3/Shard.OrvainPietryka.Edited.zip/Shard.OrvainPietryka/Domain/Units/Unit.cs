﻿using Shard.OrvainPietryka.Exposition;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public abstract class Unit
    {
        public String Id { get; set; }
        public Location CurrentLocation { get; set; }
        public Location DestinationLocation { get; set; }
        public DateTime EstimatedTimeOfArrival { get; set; }
        public Task MoveTask { get; set; }
        public int Health { get; set; }

        public Unit(string id, SectorService sectorService)
        {
            Id = id;
            CurrentLocation = sectorService.generateRandomLocation();
            DestinationLocation = null;
        }

        public Unit(string id, Location location)
        {
            Id = id;
            CurrentLocation = location;
            DestinationLocation = location;
        }

        public virtual void Move(Location destinationLocation, IClock fakeClock)
        {
            DestinationLocation = destinationLocation;
            CurrentLocation.Planet = null;
            var eta = fakeClock.Now;
            if (destinationLocation.StarSystem.Name != CurrentLocation.StarSystem.Name)
            {
                EstimatedTimeOfArrival = eta.AddMinutes(1);
            }
            if (destinationLocation.Planet != null)
            {
                EstimatedTimeOfArrival = eta.AddSeconds(15);
            }
            MoveTask = MoveAsync(destinationLocation, fakeClock);
        }
        private async Task MoveAsync(Location destinationLocation, IClock fakeClock)
        {
            if (destinationLocation.StarSystem.Name != CurrentLocation.StarSystem.Name)
            {
                await fakeClock.Delay(60 * 1000);
                CurrentLocation.StarSystem = destinationLocation.StarSystem;
            }
            if (destinationLocation.Planet?.Name != null)
            {
                await fakeClock.Delay(15 * 1000);
                CurrentLocation.Planet = destinationLocation.Planet;
            }
            CurrentLocation = destinationLocation;
            DestinationLocation = null;
            MoveTask = null;
        }

    }
}
