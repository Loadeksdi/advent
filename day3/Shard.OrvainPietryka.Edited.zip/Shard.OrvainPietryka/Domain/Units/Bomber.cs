﻿using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain.Units
{
    public class Bomber : CombatUnit
    {
        public Bomber(string id, Location location): base(id, location)
        {
            Health = 50;
            Weapons.Add(new Bomb(400));
            Preference.Add(typeof(Cruiser));
            Preference.Add(typeof(Bomber));
            Preference.Add(typeof(Fighter));
        }
    }
}
