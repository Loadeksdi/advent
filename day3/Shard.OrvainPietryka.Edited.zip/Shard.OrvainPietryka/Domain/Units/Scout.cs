﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public class Scout : Unit
    {
        public Scout(string id, Location location): base(id, location)
        {

        }

        public Scout(string id, SectorService sectorService) : base(id, sectorService)
        {

        }
    }
}
