﻿using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain.Units
{
    public class Cruiser : CombatUnit
    {
        public Cruiser(string id, Location location) : base(id, location)
        {
            Health = 400;
            for(int i = 0; i < 4; i++)
            {
                Weapons.Add(new Gun(10));
            }
            Preference.Add(typeof(Fighter));
            Preference.Add(typeof(Cruiser));
            Preference.Add(typeof(Bomber));
        }
    }
}
