﻿using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain.Units
{
    public class Fighter : CombatUnit
    {
        public Fighter(string id, Location location) : base(id, location)
        {
            Health = 80;
            Weapons.Add(new Gun(10));
            Preference.Add(typeof(Bomber));
            Preference.Add(typeof(Fighter));
            Preference.Add(typeof(Cruiser));
        }
    }
}
