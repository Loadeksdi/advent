﻿using Shard.OrvainPietryka.Domain.Units;
using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain
{
    public abstract class CombatUnit : Unit
    {
        public List<Weapon> Weapons { get; set; } = new();
        public List<Type> Preference { get; set; } = new();
        public CombatUnit(string id, Location location) : base(id, location)
        {

        }

        public void Shoot(CombatUnit enemyUnit, User enemyUser, IClock clock)
        {
            if (enemyUnit != null && enemyUser != null)
            {
                this.Weapons.ForEach(weapon => {
                    if (weapon.ShouldFire(clock.Now))
                    {
                        int damageModifier = 1;
                        if (enemyUnit.GetType() == typeof(Bomber) && this.GetType() == typeof(Cruiser))
                        {
                            damageModifier = 10;
                        }
                        enemyUnit.Health -= weapon.Damage / damageModifier;
                    }
                });
            }
        }

        public (CombatUnit, User) FindTarget(UserService userService, User currentUser)
        {
            var availableUsers = userService.Users.Where(iterableUser => iterableUser.Id != currentUser.Id).ToList();
            List<(CombatUnit, User)> firstChoices = new();
            List<(CombatUnit, User)> secondChoices = new();
            List<(CombatUnit, User)> thirdChoices = new();
            availableUsers.ForEach(user => {
                var units = user.Units.FindAll(unit => unit.GetType().IsSubclassOf(typeof(CombatUnit)) && IsUnitTargetable((CombatUnit)unit));
                firstChoices.Add(((CombatUnit) units.FirstOrDefault(combatUnit => combatUnit.GetType() == this.Preference[0]),user));
                secondChoices.Add(((CombatUnit) units.FirstOrDefault(combatUnit => combatUnit.GetType() == this.Preference[1]),user));
                thirdChoices.Add(((CombatUnit) units.FirstOrDefault(combatUnit => combatUnit.GetType() == this.Preference[2]), user));
            });
            if (!firstChoices.TrueForAll(tuple => tuple.Item1 == null))
            {
                return firstChoices.Find(tuple => tuple.Item1 != null);
            }
            if (!secondChoices.TrueForAll(tuple => tuple.Item1 == null))
            {
                return secondChoices.Find(tuple => tuple.Item1 != null);
            }
            if (!thirdChoices.TrueForAll(tuple => tuple.Item1 == null))
            {
                return thirdChoices.Find(tuple => tuple.Item1 != null);
            }
            return (null, null);
        }

        private bool IsUnitTargetable(CombatUnit combatUnit)
        {
            return (this.CurrentLocation == combatUnit.CurrentLocation
            || (this.CurrentLocation.Planet == null && combatUnit.CurrentLocation.Planet == null
            && this.CurrentLocation.StarSystem == combatUnit.CurrentLocation.StarSystem));
        }
    }
}
