﻿using Shard.OrvainPietryka.Domain.Buildings;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Domain.Units
{
    public class Cargo : Unit
    {
        public Dictionary<ResourceKind, int> ResourcesQuantity { get; set; } = new();
        public Cargo(string id, Location location): base(id, location)
        {
            Health = 100;
        }

        public bool LoadOrUnload(User user, IReadOnlyDictionary<ResourceKind, int> resourcesQuantity)
        {
            Dictionary<ResourceKind, int> result = new();
            resourcesQuantity.ToList().ForEach(resource =>
            {
                result[resource.Key] = resource.Value - this.ResourcesQuantity.GetValueOrDefault(resource.Key, 0);
            });
            if (result.Any(resource => resource.Value > 0 && user.ResourcesQuantity[resource.Key] < resource.Value))
            {
                return false;
            }
            result.ToList().ForEach(resource =>
            {
                if (user.ResourcesQuantity.ContainsKey(resource.Key))
                {
                    user.ResourcesQuantity[resource.Key] -= resource.Value;
                }
            });
            
            this.ResourcesQuantity = (Dictionary<ResourceKind, int>)resourcesQuantity;
            return true;
        }

    }
}
