﻿using System;

namespace Shard.OrvainPietryka
{
    
    public class Wormhole
    {
        public class Server
        {
            public Uri BaseUri { get; }
            public StarSystem System { get; }
            public string User { get; }
            public string SharedPassword { get; }
            public Server(Uri baseUri, StarSystem system, string user, string sharedPassword)
            {
                BaseUri = baseUri;
                System = system;
                User = user;
                SharedPassword = sharedPassword;
            }
        }

        public string Name { get; } 
        public Server ServerObject { get; }

        public Wormhole(string name, Uri baseUri, StarSystem system, string user, string sharedPasssword)
        {
            Name = name;
            ServerObject = new Server(baseUri, system, user, sharedPasssword);
        }

        
    }

}