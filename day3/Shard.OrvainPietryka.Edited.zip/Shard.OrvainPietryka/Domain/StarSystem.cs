﻿using Shard.OrvainPietryka.Domain;
using System.Collections.Generic;

namespace Shard.OrvainPietryka
{
    public class StarSystem
    {
        public string Name { get; }
        public List<Planet> Planets { get; }
        public List<Wormhole> Wormholes { get; } = new();
        public StarSystem(string name, List<Planet> planets)
        {
            Name = name;
            Planets = planets;
        }
    }
}