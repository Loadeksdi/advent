﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Services
{
    public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {

        public BasicAuthenticationHandler(
            IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock
            )
            : base(options, logger, encoder, clock)
        {

        }

        protected override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var endpoint = Context.GetEndpoint();
            if (!Request.Headers.ContainsKey("Authorization"))
            {
                return Task.Run(() => AuthenticateResult.NoResult());
            }
            try
            {
                var authHeader = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"]);
                var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                var credentials = Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);
                var username = credentials[0];
                var password = credentials[1];
                if (username == "admin" && password == "password")
                {
                    var claims = new[] {
                        new Claim(ClaimTypes.Role, "admin")
                    };
                    var identity = new ClaimsIdentity(claims, Scheme.Name);
                    var principal = new ClaimsPrincipal(identity);
                    var ticket = new AuthenticationTicket(principal, Scheme.Name);
                    return Task.Run(() => AuthenticateResult.Success(ticket));
                }
                else if (username.StartsWith("shard-"))
                {
                    var claims = new[] {
                        new Claim(ClaimTypes.Name, username[6..]),
                        new Claim(ClaimTypes.Role, "shard")
                    };
                    var identity = new ClaimsIdentity(claims, Scheme.Name);
                    var principal = new ClaimsPrincipal(identity);
                    var ticket = new AuthenticationTicket(principal, Scheme.Name);
                    return Task.Run(() => AuthenticateResult.Success(ticket));
                }
                else
                {
                    return Task.Run(() => AuthenticateResult.Fail("Bad credentials"));
                }
            }
            catch
            {
                return Task.Run(() => AuthenticateResult.Fail("Invalid Authorization Header"));
            }
        }
    }
}