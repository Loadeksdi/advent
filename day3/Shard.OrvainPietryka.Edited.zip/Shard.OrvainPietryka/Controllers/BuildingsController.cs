﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shard.OrvainPietryka.Domain;
using Shard.OrvainPietryka.Domain.Buildings;
using Shard.OrvainPietryka.Exposition;
using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Controllers
{
    [Route("users/")]
    [ApiController]
    public class BuildingsController : ControllerBase
    {
        private readonly SectorService _sectorService;
        private readonly UserService _userService;
        private readonly IClock _clock;
        public BuildingsController(UserService userService, SectorService sectorService, IClock clock)
        {
            _sectorService = sectorService;
            _userService = userService;
            _clock = clock;
        }

        [HttpPost("{userId}/buildings")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<ExposedBuilding> CreateBuilding(string userId, ExposedBuilding building)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            var builder = (Builder)user.Units.Find(unit => unit.Id == building.BuilderId);
            if (building == null || builder == null || builder.CurrentLocation.Planet == null)
            {
                return BadRequest();
            }
            if (building.Type == "mine")
            {
                var mine = new Mine(builder, building.ResourceCategory);
                user.Buildings.Add(mine);
                builder.BuildBuilding(mine, user, _clock);
                return CreatedAtAction(nameof(GetBuilding), new { userId, buildingId = mine.Id }, new ExposedBuilding(mine));
            }
            else if (building.Type == "starport")
            {
                var starport = new Starport(builder);
                user.Buildings.Add(starport);
                builder.BuildBuilding(starport, user, _clock);
                return CreatedAtAction(nameof(GetBuilding), new { userId, buildingId = starport.Id }, new ExposedBuilding(starport));
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpGet("{userId}/buildings")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<List<ExposedBuilding>> GetBuildings(string userId)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            return user.Buildings.Select(building =>
            building.GetType().Name.ToLower() switch
            {
                "mine" => new ExposedBuilding((Mine)building),
                _ => new ExposedBuilding(building),
            }).ToList();
        }

        [HttpGet("{userId}/buildings/{buildingId}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<ExposedBuilding>> GetBuilding(string userId, string buildingId)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            var building = user.Buildings.Find(building => building.Id == buildingId);
            if (building == null)
            {
                return NotFound();
            }
            var builder = (Builder)user.Units.Find(unit => unit.Id == building.BuilderId);
            if (builder.BuildTask != null && (building.EstimatedBuildTime - _clock.Now).TotalSeconds <= 2)
            {
                try
                {
                    await builder.BuildTask;
                }
                catch (TaskCanceledException)
                {
                    builder.BuildTask = null;
                    return NotFound();
                }
            }
            return building.GetType().Name.ToLower() switch
            {
                "mine" => new ExposedBuilding((Mine)building),
                _ => new ExposedBuilding(building),
            };
        }

        [HttpPost("{userId}/buildings/{starportId}/queue")]
        [Consumes(MediaTypeNames.Application.Json)]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<ExposedBuilding> CreateUnit(string userId, string starportId, ExposedUnit unit)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            var building = user.Buildings.Find(building => building.Id == starportId );
            if (building == null)
            {
                return NotFound();
            }
            if (building.GetType().Name.ToLower() != "starport" || building.IsBuilt == false)
            {
                return BadRequest();
            }
            var starport = (Starport)building;
            var createdUnit = starport.CreateUnit(unit, user, _userService, _clock);
            if (createdUnit != null)
            {
                return Ok(new ExposedUnit(createdUnit));
            }
            return BadRequest();
        }
    }
}
