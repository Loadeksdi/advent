﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shard.OrvainPietryka.Domain;
using Shard.OrvainPietryka.Exposition;
using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mime;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserService _userService;
        private readonly SectorService _sectorService;
        public UsersController(UserService userService, SectorService sectorService)
        {
            _userService = userService;
            _sectorService = sectorService;
        }

        [HttpGet("{id}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<ExposedUser> GetUserById(string id)
        {
            var user = _userService.Users.Find(user => user.Id == id);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            return new ExposedUser(user);
        }

        [HttpPut("{id}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<ExposedUser> CreateUser(string id, User user)
        {
            if (id != user.Id || !Regex.Match(id, "^[a-zA-Z0-9-_]+$").Success)
            {
                return BadRequest();
            }
            var existingUser = _userService.Users.Find(existingUser => existingUser.Id == id);
            if (HttpContext.User.IsInRole("admin"))
            {
                user.ResourcesQuantity.ToList().ForEach(resource => existingUser.ResourcesQuantity[resource.Key] = resource.Value);
            }
            if (existingUser != null)
            {
                return new ExposedUser(existingUser);
            }
            if (existingUser == null && HttpContext.User.IsInRole("shard"))
            {
                user.ResourcesQuantity.Clear();
                user.ResourcesQuantity.Add(ResourceKind.Carbon, 0);
                user.ResourcesQuantity.Add(ResourceKind.Iron, 0);
                user.ResourcesQuantity.Add(ResourceKind.Gold, 0);
                user.ResourcesQuantity.Add(ResourceKind.Aluminium, 0);
                user.ResourcesQuantity.Add(ResourceKind.Titanium, 0);
                user.ResourcesQuantity.Add(ResourceKind.Oxygen, 0);
                user.ResourcesQuantity.Add(ResourceKind.Water, 0);
            }
            else
            {
                user.CreateInitialUnits(_sectorService);
            }
            _userService.Users.Add(user);
            return CreatedAtAction(nameof(GetUserById), new { id = user.Id }, new ExposedUser(user));
        }

    }
}
