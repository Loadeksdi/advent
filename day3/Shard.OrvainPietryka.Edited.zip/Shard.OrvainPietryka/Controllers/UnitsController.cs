﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Shard.OrvainPietryka.Domain;
using Shard.OrvainPietryka.Domain.Buildings;
using Shard.OrvainPietryka.Domain.Units;
using Shard.OrvainPietryka.Exposition;
using Shard.OrvainPietryka.Services;
using Shard.Shared.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Controllers
{
    [Route("/users")]
    [ApiController]
    public class UnitsController : ControllerBase
    {
        private readonly UserService _userService;
        private readonly SectorService _sectorService;
        private readonly WormholeService _wormholeService;
        private readonly IClock _clock;
        public UnitsController(UserService userService, SectorService sectorService, WormholeService wormholeService, IClock clock)
        {
            _userService = userService;
            _sectorService = sectorService;
            _wormholeService = wormholeService;
            _clock = clock;
        }

        [HttpGet("{userId}/Units")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<List<ExposedUnit>> GetUnitsFromUser(string userId)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            var exposedUnits = new List<ExposedUnit>();
            user.Units.ForEach(unit => exposedUnits.Add(new ExposedUnit(unit)));
            return exposedUnits;
        }

        [HttpGet("{userId}/Units/{unitId}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<ExposedUnit>> GetUnitById(string userId, string unitId)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            var unit = user.Units.Find(unit => unit.Id == unitId);
            if (unit == null)
            {
                return NotFound("This unit is not owned by this user");
            }
            if (unit.MoveTask == null)
            {
                return new ExposedUnit(unit);
            }
            else
            {
                if ((unit.EstimatedTimeOfArrival - _clock.Now).TotalSeconds <= 2)
                {
                    await unit.MoveTask;
                }
                return new ExposedUnit(unit);
            }
        }

        [HttpPut("{userId}/Units/{unitId}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<ExposedUnit>> ExploreAnotherLocation(string userId, string unitId, [FromBody] ExposedUnit unit)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            var existingUnit = user.Units.Find(unit => unit.Id == unitId);
            bool justCreated = false;
            if (existingUnit == null && HttpContext.User.IsInRole("admin"))
            {
                var system = _sectorService.Systems.Find(system => system.Name == unit.System);
                var planet = system.Planets.Find(planet => planet.Name == unit.Planet);
                existingUnit = _userService.CreateAndAddUnit(unit, user, new Location(planet, system));
                justCreated = true;
            }
            else if (existingUnit == null && HttpContext.User.IsInRole("shard"))
            {
                var shardName = HttpContext.User.Identity.Name;
                var system = _sectorService.Systems.Find(system => system.Wormholes.Exists(wormhole => wormhole.Name == shardName));
                existingUnit = _userService.CreateAndAddUnit(unit, user, new Location(null, system));
                justCreated = true;
            }
            else if (existingUnit == null)
            {
                return Unauthorized();
            }


            var requestIsMovingRequest = (unit.DestinationSystem != unit.System || unit.DestinationPlanet != unit.Planet);
            if (requestIsMovingRequest && !justCreated)
            {
                var destinationSystem = _sectorService.Systems.Find(system => system.Name == unit.DestinationSystem);
                Planet destinationPlanet = null;
                var destinationSystemNotFoundSoWeShouldInspectActualSystem = destinationSystem is null;
                if (destinationSystemNotFoundSoWeShouldInspectActualSystem)
                {
                    var actualSystem = _sectorService.Systems.Find(system => system.Name.Equals(unit.System));
                    if (actualSystem is not null)
                    {
                        destinationPlanet =
                            actualSystem.Planets.Find(planet => planet.Name.Equals(unit.DestinationPlanet));
                        destinationSystem = actualSystem;
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                else
                {
                    destinationPlanet = destinationSystem.Planets.Find(planet => planet.Name == unit.DestinationPlanet);
                }

                switch (unit.Type)
                {
                    case "builder":
                        var builder = (Builder) existingUnit;
                        builder.Move(new Location(destinationPlanet, destinationSystem), _clock);
                        if (builder.Building != null)
                        {
                            user.Buildings.Remove(builder.Building);
                        }

                        break;
                    default:
                        existingUnit.Move(new Location(destinationPlanet, destinationSystem), _clock);
                        break;
                }
            
            }
            if (!justCreated)
            {
                Cargo cargo = existingUnit as Cargo;
                if (cargo != null)
                {
                    var unitResourcesDictionnary = unit.ResourcesQuantity?.ToDictionary(kvp => (ResourceKind)Enum.Parse(typeof(ResourceKind), kvp.Key, true), kvp => kvp.Value);
                    bool resourceAreTheSame = AreTowContainersEquals(unitResourcesDictionnary,cargo.ResourcesQuantity);
                    if (!resourceAreTheSame)
                    {
                        var cargoPlanet = cargo.CurrentLocation.Planet;
                        if (cargoPlanet is null)
                        {
                            return BadRequest("Unit is not on planet so it can't be on starport");
                        }
                        var starport = user.Buildings.Find(building => building.GetType() == typeof(Starport) && building.Location.Planet == cargoPlanet);
                        if (starport == null || !starport.IsBuilt)
                        {
                            return BadRequest();
                        }
                        var resourcesUpdate = cargo.LoadOrUnload(user, unitResourcesDictionnary);
                        if (!resourcesUpdate)
                        {
                            return BadRequest();
                        }       
                    }

                }
                else if (cargo == null && unit.ResourcesQuantity?.Count > 0)
                {
                    return BadRequest();
                }
            }
            if ((HttpContext.User.IsInRole("admin") || !HttpContext.User.Identity.IsAuthenticated) && unit.DestinationShard != null)
            {
                var wormhole = existingUnit.CurrentLocation.StarSystem.Wormholes.Find(wormhole => unit.DestinationShard == wormhole.Name);
                if (wormhole == null)
                {
                    return BadRequest();
                }
                var result = await _wormholeService.JumpInRemoteShard(wormhole, new ExposedUser(user), unit);
                if (result == null)
                {
                    return StatusCode(502);
                }
                user.Units.Remove(existingUnit);
                return RedirectPermanentPreserveMethod(result);
            }
            return new ExposedUnit(existingUnit);
        }

        private bool AreTowContainersEquals(Dictionary<ResourceKind, int> mappedDtoResources, Dictionary<ResourceKind, int> cargoUnitResourceContainer)
        {
            foreach (var (resourceType,quantity) in mappedDtoResources)
            {
                if (cargoUnitResourceContainer.ContainsKey(resourceType))
                {
                    if (cargoUnitResourceContainer[resourceType] != quantity)
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            foreach (var (resourceType,quantity) in cargoUnitResourceContainer)
            {
                if (mappedDtoResources.ContainsKey(resourceType))
                {
                    if (mappedDtoResources[resourceType] != quantity)
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }

            return true;
        }

        [HttpGet("{userId}/Units/{unitId}/location")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<ExposedLocation> GetLocationFromUnit(string userId, string unitId)
        {
            var user = _userService.Users.Find(user => user.Id == userId);
            if (user == null)
            {
                return NotFound("This user does not exist");
            }
            var unit = user.Units.Find(unit => unit.Id == unitId);
            if (unit == null)
            {
                return NotFound("This unit is not owned by this user");
            }
            return new ExposedLocation(unit);
        }

    }
}
