﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Threading.Tasks;

namespace Shard.OrvainPietryka.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SystemsController : ControllerBase
    {
        private readonly SectorService _sectorService;

        public SystemsController(SectorService sectorService)
        {
            _sectorService = sectorService;
        }

        [HttpGet]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<List<ExposedStarSystem>> GetAllSystems()
        {
            return _sectorService.Systems.Select(starSystem => new ExposedStarSystem(starSystem)).ToList();
        }

        [HttpGet("{systemName}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<ExposedStarSystem> GetSystemByName(string systemName)
        {
            var starSystem = _sectorService.Systems.Find(solarSystem => solarSystem.Name == systemName);
            if (starSystem == null)
            {
                return NotFound("This system does not exist.");
            }
            return new ExposedStarSystem(starSystem);
        }

        [HttpGet("{systemName}/planets")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<List<ExposedPlanet>> GetPlanetsBySystem(string systemName)
        {
            var starSystem = _sectorService.Systems.Find(solarSystem => solarSystem.Name == systemName);
            if (starSystem == null)
            {
                return NotFound("This system does not exist.");
            }
            return starSystem.Planets.Select(planet => new ExposedPlanet(planet)).ToList();
        }

        [HttpGet("{systemName}/planets/{planetName}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public ActionResult<ExposedPlanet> GetPlanetByNameInsideSystem(string systemName, string planetName)
        {
            var starSystem = _sectorService.Systems.Find(solarSystem => solarSystem.Name == systemName);
            if (starSystem == null)
            {
                return NotFound("This system does not exist.");
            }
            var planet = starSystem.Planets.Find(planet => planet.Name == planetName);
            if (planet == null)
            {
                return NotFound("This planet does not exist in " + starSystem.Name + " star system.");
            }
            return new ExposedPlanet(planet);
        }

    }
}
